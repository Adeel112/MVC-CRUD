﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
public class car 
{
    public string make="Ford";
    public string model="Mustang";
}
public class car2 
{
    public string make="Ford";
    public string model="Mustang";
}