﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Elfie.Model.Strings;
using Microsoft.EntityFrameworkCore;
using StudentPortal.Web.Models;
using StudentPortal.Web.Models.Data;

namespace StudentPortal.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeDbContext _Db;
        public EmployeeController(EmployeeDbContext context)
        {
            this._Db = context;
        }
        public async Task<IActionResult> Index()
        {
            var employees = await _Db.Employees.ToListAsync();
            return View(employees);
        }
        public async Task<IActionResult> Create() // View generation
        {
            // Simulate async behavior to resolve CS1998
            await Task.CompletedTask;
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Employee Obj) // View generation
        {
            if (ModelState.IsValid)
            {
                _Db.Employees.Add(Obj);
                await _Db.SaveChangesAsync();
                TempData["Success Message"] = "Employee Created Successfully!";
                return RedirectToAction("Index");
            }   
            // Simulate async behavior to resolve CS1998
            await Task.CompletedTask;
            return View(Obj);
        }
        public async Task<IActionResult> Edit(int id) // View generation
        {
            var employee = await _Db.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(int id, Employee Obj)
        { 
            if(id != Obj.Emp_ID)
        {
            return NotFound();
        }
            if (ModelState.IsValid)
            {
                _Db.Employees.Update(Obj);
                await _Db.SaveChangesAsync();
                TempData["Success Message"] = "Employee Updated Successfully!";
                return RedirectToAction("Index");
            }
            return View(Obj);
        }
        public async Task<IActionResult> Details(int id)
        {
            var employee = await _Db.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }
        public async Task<IActionResult> Delete(int id) // View generation
        {
           
            var employee = await _Db.Employees.FindAsync(id);
            if (employee != null)
            {
                _Db.Employees.Remove(employee);
                await _Db.SaveChangesAsync();
                TempData["Success Message"] = "Employee Deleted Successfully!";
            }
            else
            {
                TempData["Error Message"] = "Employee Not Found!";
            }
            return RedirectToAction("Edit", new { id = 1 });

        }

    }
}
