﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace StudentPortal.Web.Models
{
    public class Employee
    {
        [Key]
        [DisplayName("ID")]
        public int Emp_ID { get; set; }
        
        [Required]
        [MaxLength(200)]
        [DisplayName("Name")]
        public required string Emp_Name { get; set; }
        [Required]
        [DisplayName("Age")]
        public int Emp_Age { get; set; }
        [Required]
        [DisplayName("Gender")]
        public int Emp_Gender { get; set; }
        [Required]
        [DisplayName("DOJ")]
        public DateTime Emp_DOJ { get; set; }
        [Required]
        [DisplayName("Designation")]
        public required string Designation { get; set; }
        [Required]
        [DisplayName("Salary")]
        public int Salary { get; set; }

    }
}
